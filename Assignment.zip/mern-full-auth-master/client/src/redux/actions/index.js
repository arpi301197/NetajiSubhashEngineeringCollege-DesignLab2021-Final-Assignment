const ACTIONS = {
    LOGIN: 'LOGIN',
    GET_TOKEN: 'GET_TOKEN',
    GET_USER: 'GET_USER',
    GET_ALL_USERS: 'GET_ALL_USERS'
}

export default ACTIONS